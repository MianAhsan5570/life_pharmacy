<div class="row">
					<div class="col-sm-4">
						<a href="orders.php?o=add" class="thumbnail mainMenu" style="text-decoration: none;color: green;">
							<h3 class="text-center">
								<span class="glyphicon glyphicon-plus-sign"></span><hr>
								Add Orders
							</h3>
						</a>
					</div><!-- col -->
					<div class="col-sm-4">
						<a href="orders.php?o=manord" class="thumbnail mainMenu" style="text-decoration: none;color: gray;">
							<h3 class="text-center">
								<span class="glyphicon glyphicon-edit"></span><hr>
								Manage Orders
							</h3>
						</a>
					</div><!-- col -->
					<div class="col-sm-4">
						<a href="demand.php" class="thumbnail mainMenu" style="text-decoration: none;color: #000;">
							<h3 class="text-center">
								<span class="fa fa-file-o"></span><hr>
								Demand Report
							</h3>
						</a>
					</div><!-- col -->
					</div>
					<div class="row">
					<div class="col-sm-4">
						<a href="product.php" class="thumbnail mainMenu" style="text-decoration: none;color: #000;">
							<h3 class="text-center">
								<span class="glyphicon glyphicon-ruble"></span><hr>
								Products
							</h3>
						</a>
					</div><!-- col -->
					
					<div class="col-sm-4">
						<a href="report.php" class="thumbnail mainMenu" style="text-decoration: none;color:#000;">
							<h3 class="text-center">
								<span class="fa fa-file-o"></span><hr>
								Sale Report
							</h3>
						</a>
					</div><!-- col -->
					
					
					
					<div class="col-sm-4">
						<a href="logout.php" class="thumbnail mainMenu" style="text-decoration: none;color: red;">
							<h3 class="text-center">
								<span class="glyphicon glyphicon-off"></span><hr>
								Logout
							</h3>
						</a>
					</div><!-- col -->
					</div>
					
					
			</div>	
		</div>
		
	</div>

	
</div> <!--/row-->
